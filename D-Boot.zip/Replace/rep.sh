#1/bin/bash
read -p "Masukan List : " list;
sed 's/#/|/1;s/@/|/1' $list >> list1.txt
echo "Result : list1.txt"
